#!/usr/bin/env bash
# Apply the full bundle to a fresh Supabase project.
# Usage:
#   DATABASE_URL=postgres://postgres:PASSWORD@db.NEWREF.supabase.co:5432/postgres bash 14_apply_all.sh
set -e
: "${DATABASE_URL:?set DATABASE_URL to the new project's Postgres URL}"
cd "$(dirname "$0")"

run() {
  echo "==> $1"
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$1"
}

run 00_extensions.sql
run 01_tables.sql
run 02_constraints.sql
run 03_indexes.sql
run 09_sequences.sql
run 04_functions.sql
run 05_triggers.sql
run 10_views.sql
run 06_grants.sql
run 07_rls_enable.sql
run 08_policies.sql

echo "==> Loading data (CSVs)"
bash 12_data_load.sh

echo ""
echo "Done. Next: deploy edge functions listed in 13_edge_functions.txt"
echo "  cd <repo> && supabase functions deploy"

# DB Bundle — exported from live Supabase

Apply order (already encoded in 14_apply_all.sh):
00 extensions → 01 tables → 02 constraints → 03 indexes → 09 sequences →
04 functions → 05 triggers → 10 views → 06 grants → 07 RLS enable →
08 policies → 11 data (via 12_data_load.sh)

Then deploy edge functions named in 13_edge_functions.txt.

Caveats:
- auth/storage/vault schemas excluded (managed by Supabase).
- Auth users not exported — recreate via Dashboard or seed-demo-users edge fn.
- 0 storage buckets in source project.
- Grants generated from policy roles (authenticated + service_role on every table; anon SELECT where any policy targets anon).
